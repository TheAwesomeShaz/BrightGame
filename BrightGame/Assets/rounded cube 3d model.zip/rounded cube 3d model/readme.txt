The contents of this zip file are licensed under the
Creative Commons Attribution-ShareAlike license.
http://creativecommons.org/licenses/by-sa/3.0/

For the attribution part of the license, if you 
release a game (or other work) using the rounded 
cube please leave a comment sharing the name of your 
project (a link is great too).  No other attribution 
is required.

Created by Bryan Duke, Acceleroto, Inc.
Copyright 2013.  Acceleroto, Inc.